import { faEnvelope, faHome, faPhone } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { Link, useNavigate } from 'react-router-dom';
import React, { useState } from 'react';
import './Contact.css';
import Header from '../components/header/Header';
import axios from 'axios';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const Contact = () => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phno, setPhno] = useState("");
    const [subject, setSubject] = useState("");
    const [message, setMessage] = useState("");
    const navigate = useNavigate()
    const contactHandler = async(e) => {
        e.preventDefault()
    const userDa = {
        name,
        email,
        phno,
        subject,
        message,
        }
        const response = await axios.post('http://localhost:1099/Contact', userDa)
        console.log(response)
        setName("")
        setEmail("")
        setPhno("")
        setSubject("")
        setMessage("")
        toast.success("Contact test")
        setTimeout(() => { navigate("/home") }, 2000)
        
        
    }
    return (
        <>
        <Header searchReq={true} />
        <div className='contactContainer'>
            
            <section className="contactUs-wrapper">
                <div className="single-contact icon1">
                    <div className="c-icon">
                        <FontAwesomeIcon icon={faHome} />
                    </div>
                    <div className="c-info text-start">
                        <h4>Address</h4>
                        <p>55 West, 33rd Street</p>
                        <p>5th Floor, New York</p>
                    </div>
                </div>
                <div className="single-contact icon2">
                    <div className="c-icon">
                        <FontAwesomeIcon icon={faEnvelope} />
                    </div>
                    <div className="c-info text-start">
                        <h4>Email</h4>
                        <p>info@email.com</p>
                        <p>email@gmail.com</p>
                    </div>
                </div>
                <div className="single-contact icon3">
                    <div className="c-icon">
                        <FontAwesomeIcon icon={faPhone} />
                    </div>
                    <div className="c-info text-start">
                        <h4>Phone</h4>
                        <p>(+91)7997168111</p>
                        <p>(+91)7721153367</p>
                    </div>
                </div>
            </section>
            
            <h1 style={{textAlign:"center", fontSize:"35px", marginTop:"20px"}}>Contact us</h1>
            <form className="contactusForm" onSubmit={contactHandler}>
                <div className='ContactUsRow'>
                    <input type="text" placeholder="Name"  value={name} onChange={(e) => setName(e.target.value)}/>
                    <input type="email" placeholder="Email"  value={email} onChange={(e) => setEmail(e.target.value)}/>
                </div>
                <div className='ContactUsRow'>
                        <input type="phone" placeholder="Phone" value={phno} onChange={(e) => setPhno(e.target.value)}/>
                    <input type="text" placeholder="Subject"  value={subject} onChange={(e) => setSubject(e.target.value)}/>
                </div>
                <div className='ContactusRow'>
                    <textarea name="Message" id="" cols="22" rows="7" value={message} placeholder="Message" onChange={(e) => setMessage(e.target.value)}></textarea>
                </div>
                <div className='ContactButton'>
                    <button>Submit</button>
                </div>
                </form>
                <ToastContainer/>
            </div>
            </>
    );
};

export default Contact;