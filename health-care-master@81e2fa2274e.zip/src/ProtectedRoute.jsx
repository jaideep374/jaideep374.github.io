import { useSelector } from "react-redux";
import { Navigate } from 'react-router-dom';
import Appoint from "./appointment/Appointment";


const ProtectedRoute = ({children})=>{
    // const isAuthenticated = useSelector((state)=>state.authReducer.authInitialState)
    const user = localStorage.getItem('token-info')
    
    if(!user){
        
        return <Navigate to="/signin"/>
    }
    
    return children
}
export default ProtectedRoute;
