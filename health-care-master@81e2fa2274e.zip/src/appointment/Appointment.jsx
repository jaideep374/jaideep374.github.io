import React, { useState, useRef, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { v4 as uuid } from 'uuid';
// import {FaThumbsUp} from 'react-icons/fa'
import { FaThumbsUp } from 'react-icons/fa6'
import { MdVerified } from 'react-icons/md';

import Header from '../components/header/Header';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import './Appoint.css';


function Appoint() {

    const location = useLocation();
    const doctor_name = location.state.doctorname;
    const fee = location.state.fee;
    const role = location.state.role;
    // console.log(doctor_name, fee, role)

    const ref = useRef(null);

    var uname = ""
    var phone = ""
    try {
        uname = (JSON.parse(localStorage.getItem('token-info'))).username;
        phone = (JSON.parse(localStorage.getItem('token-info'))).phno;
        console.log("phone", phone)
    }
    catch {
        navigate("/signin");
    }
    const [img, setDocimg] = useState("https://th.bing.com/th/id/OIP.Yzu-EyLuD6Lxwym4zei4vAHaHW?pid=ImgDet&rs=1")
    const navigate = useNavigate();
    const [doctorname, setDoctorname] = useState(doctor_name)
    const [dfee, setDfee] = useState(fee);
    const [pname, setPname] = useState();
    const [pno, setPno] = useState();
    const [date, setDate] = useState();
    const [time, setTime] = useState("");
    const [health, setHealth] = useState("");
    const [gender, setGender] = useState("male");
    const [timeof, setTimeOf] = useState("");
    const [todaydate, setTodayDate] = useState();
    const options = ["09:00", "09:30", "10:00", "10:30", "11:00", "11:30", "12:00", "12:30", "17:00", "17:30", "18:00", "18:30", "19:00", "19:30"];
    const timeofday = ["morning", "afternoon", "evening"];
    // const for_whom_to_book = ["myself", "relatives"]
    const [slots, setSlots] = useState([]);
    const [appointId, setAppointId] = useState("");
    const [availabletime, setAvailableTime] = useState([]);
    const [updatedtime, setUpdatedTime] = useState([]);
    const [forwhom, setForWhom] = useState("");


    useEffect(() => {
        console.log(1)
        const today = new Date()
        let dd = today.getDate();
        let mm = today.getMonth() + 1;
        let yyyy = today.getFullYear();
        if (mm < 10)
            mm = '0' + mm
        if (dd < 10)
            dd = '0' + dd
        const newDate = yyyy + '-' + mm + '-' + dd;
        const unique_id = uuid();
        const small_id = unique_id.slice(0, 8);
        setAppointId(small_id)
        setDate(newDate);
        setTodayDate(newDate);
    }, [])
    console.log(appointId)
    useEffect(() => {
        console.log(2)
        let today = new Date();
        let time = today.getHours() + ":" + today.getMinutes();
        let arr = slots.map((e) => {
            // console.log(todayDate, " ", e.date)
            if (date === e.date && e.doctorname === doctorname)
                return e.time
        })
        let res = options.filter((e) => !(arr.includes(e)))
        // setAvailableTime(res);
        console.log("date", date, todaydate);
        if (date === todaydate) {
            let w = res.filter((e) => {
                console.log(e);
                if (parseInt(e.slice(0, 2)) === parseInt(time.slice(0, 2))) {
                    if (parseInt(e.slice(3, 5)) > parseInt(time.slice(3, 5))) {
                        console.log("inside", e)
                        return e;
                    }
                }
                else if (parseInt(e.slice(0, 2)) > parseInt(time.slice(0, 2))) {
                    console.log("h1", parseInt(e.slice(3, 5)), parseInt(time.slice(3, 5)))
                    return e;

                }
            })
            console.log("w", w);
            setAvailableTime(w);
        }
        else {
            setAvailableTime(res);
        }
        console.log("hello", availabletime)
    }, [slots])
    const fetechSlots = () => {
        // fetechDates();
        if (timeof === "morning") {
            let res = availabletime.filter((e) => {
                if (parseInt(e.slice(0, 2)) >= 1 && parseInt(e.slice(0, 2)) < 12)
                    return e
            })
            setUpdatedTime(res);
        }
        else if (timeof === "afternoon") {
            let res = availabletime.filter((e) => {
                if (parseInt(e.slice(0, 2)) >= 12 && parseInt(e.slice(0, 2)) < 16)
                    return e
            })
            setUpdatedTime(res);
        }
        else if (timeof === "evening") {
            let res = availabletime.filter((e) => {
                if (parseInt(e.slice(0, 2)) >= 16 && parseInt(e.slice(0, 2)) <= 20)
                    return e
            })
            setUpdatedTime(res);
        }
    }
    useEffect(() => {
        fetechSlots();
    }, [date, timeof])
    const fetechDates = () => {
        return fetch("http://localhost:1099/slots")
            .then((res) => res.json())
            .then((d) => setSlots(d))
    }
    useEffect(() => {
        console.log(3)
        fetechDates()
    }, [date])
    const isValidate = () => {
        let isprocced = true;
        let errormessage = ""
        if (forwhom == "relatives") {
            if (pname == null) {
                isprocced = false;
                errormessage += "Please enter username"
            }
            if (pno == null) {
                isprocced = false;
                errormessage += "Please enter phone number"
            }
        }
        else if (health == "") {
            isprocced = false;
            errormessage += "Please enter health concern";
        }
        else if (time == "") {
            isprocced = false;
            errormessage += "Select time slot";
        }
        else {

            let today = new Date();
            let currtime = today.getHours() + ":" + today.getMinutes();
            console.log("nowtime", currtime)
            console.log("nowselected", time)
            const a = parseInt(time.slice(0, 2))
            const b = parseInt(time.slice(3, 5))
            console.log("now", a, b)
            if (a < parseInt(currtime.slice(0, 2))) {
                isprocced = false;
                errormessage += "Refresh the page to select correct time slot";
            }
            else if (a == parseInt(currtime.slice(0, 2))) {
                console.log("came", b, parseInt(time.slice(3, 5)))
                if (b <= parseInt(time.slice(3, 5))) {
                    isprocced = false;
                    errormessage += "Refresh the page to select correct time slot";
                }
            }
        }
        if (!isprocced) {
            toast.warning(errormessage);
        }
        return isprocced
    }
    const fun = (e) => {

        e.preventDefault();

        if (isValidate()) {
            // setDate(ref.current.value)
            console.log(uname, pname, pno, gender, doctorname, dfee, date, time, health, appointId, role, img)
            // let date = ref.current?.value
            console.log(typeof (pno), typeof (pname), "hello", phone, uname)
            var rejobj;
            if (pno == undefined && pname == undefined) {
                let pname = uname;
                let pno = phone;
                rejobj = { uname, pname, pno, gender, doctorname, dfee, date, time, health, appointId, role, img }
            }
            else
                rejobj = { uname, pname, pno, gender, doctorname, dfee, date, time, health, appointId, role, img }

            fetch("http://localhost:1099/slots", {
                method: "POST",
                headers: { 'content-type': 'application/json' },
                body: JSON.stringify(rejobj)
            }).then((res) => {
                toast.success("Appointment booked successfulley")
            }).catch((res) => {
                toast.error("Error!")
            });

            navigate("/myappointments", { state: { appointId: appointId, doctorname: doctorname } })

        }
        else {
            console.log("error!");
        }
    }

    const myself = () => {
        setForWhom("myself")


    }

    const relatives = () => {
        setForWhom("relatives")
    }

    return (

        <div className="appopintmentContainer">
            <Header searchReq={true} />
            <div className="appdoctor">
                <div className="apptitle">Request an Appointment</div>
                <div className="appdoclog">
                    <div className="appdoctorinfo">
                        <div className="appimages">
                            <div className="appimgbox">
                                <img className="appimg" src="https://th.bing.com/th/id/OIP.Yzu-EyLuD6Lxwym4zei4vAHaHW?pid=ImgDet&rs=1" alt="loading!" />
                            </div>
                            {/* <div className="apphoslogo">
                        <img src="https://newsmeter.in/wp-content/uploads/2020/01/yashoda-hospital-fined-15-lakh-for-negligence.jpg" />
                    </div> */}
                        </div>
                        <div className="context">
                            <p className="name">{doctorname}</p>
                            <p className="desc">BDS, MDS - Paedodontics And Preventive Dentistry</p>
                            <p className="desc">24 Years Experience Overall  (19 years as specialist)
                            </p>

                            <br />
                            <h3  style={{fontSize:"20px", fontWeight:"bold", color:"darkblue"}}>Consultation Fee: ₹ {fee}</h3>
                            {/* <div className="rating">
                        <MdVerified size={20} className="thumb" /> <p>Medical Registration Verified</p>
                    </div> */}
                            <br />
                            <div className="rating">
                                <FaThumbsUp size={20} className="thumb" />  <p className="t1">97%</p> <sub> (4357 votes)</sub>
                            </div>
                        </div>
                    </div>
                    <div className="appformfill">
                        <div className="app-for-whom">
                            <button className={"app-myself " + (forwhom == "relatives" ? "" : "selected")} value="myself" onClick={myself}>Myself</button>
                            <button className={"app-relatives " + (forwhom == "myself" ? "" : "selected")} onClick={relatives}>Relatives</button>
                        </div>
                        <div className="appform" >
                            <div className={"apppart1"}>
                                {forwhom === "relatives" ?
                                    <input className="appinput" value={pname} onChange={(e) => setPname(e.target.value)} type="text" placeholder="Enter patient name" required /> : ""}
                                {forwhom === "relatives" ?
                                    <input className="appinput" value={pno} onChange={(e) => setPno(e.target.value)} placeholder="Enter Phone Number" /> : ""}
                                <input className="appinput" value={health} onChange={(e) => setHealth(e.target.value)} type="tex" placeholder="Enter your Health Concern" />
                                <div className="appgenderset">
                                    <div className="app-gender-space">   <input className="appgender" value="male" checked={gender === 'male'} name='male' onChange={(e) => setGender(e.target.value)} type="radio" /> Male </div>
                                    <div className="app-gender-space"> <input className="appgender" value="female" checked={gender === 'female'} name='female' onChange={(e) => setGender(e.target.value)} type="radio" /> Female </div>
                                    {/* <input className="appgender" value="male" checked={gender === 'male'} name='male' onChange={(e) => setGender(e.target.value)} type="radio" /> Perfer Not to sa */}
                                </div>
                            </div>
                            <div className="apppart2">
                                <input className="appinputdate" min={new Date().toISOString().split("T")[0]} value={date} onChange={(e) => setDate(e.target.value)} required type="date" placeholder="select date" />

                                <select className="appinputtime" value={timeof} onChange={(e) => setTimeOf(e.target.value)}>
                                    <option>Select Available Time Slot</option>
                                    {timeofday.map((option, index) => {
                                        return <option key={index} >
                                            {option}
                                        </option>
                                    })}
                                </select>
                                {updatedtime.length === 0 ? <div className="appnoslots">No Slots are Available</div> : <div className="timeslot">
                                    {
                                        updatedtime.map((options, index) => {
                                            console.log()
                                            return (
                                                <button className={"buttime " + (time == options ? "selected" : "")} value={options} onClick={(e) => { setTime(options) }} > {options.slice(0, 2) >= 12 ? <p>{(parseInt(options.slice(0, 2)) == 12 ? parseInt(options.slice(0, 2)) : parseInt(options.slice(0, 2) - 12)) + ":" + (options.slice(3, 5)) + " pm"}</p> : <p>{options.slice(0, 2) + ":" + options.slice(3, 5) + " am"}</p>}
                                                </button>
                                            )
                                        })
                                    }
                                </div>}
                            </div>
                            <button className="appsubmit" onClick={fun}>Make an Appointment</button>
                        </div>
                    </div>
                </div>
                <ToastContainer />
            </div>
        </div>
    )
}

export default Appoint