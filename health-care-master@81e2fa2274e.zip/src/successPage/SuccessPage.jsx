import { useState } from "react";
import { useLocation } from "react-router-dom";

import './SuccessPage.css';
import Header from "../components/header/Header";




function SuccessPage() {

    const location = useLocation();
    const appointId = location.state.appointId;
    const doctor = location.state.doctortname;


    const [details, setDetails] = useState([]);
    const url = `http://localhost:1099/slots?appointId=${appointId}`;

    const fetchDetails = () => {
        return fetch(url)
            .then((e) => e.json())
            .then((e) => setDetails(e))
    };
    fetchDetails();
    return (
        <>
            <Header searchReq={false}/>
            <div className="main"> Your Appointment With {doctor} is Conformed!

                {
                    details.map((dataObj) => {

                        return (
                            <div key={dataObj.id}>
                                <p> {dataObj.pname} </p>
                                <p>{dataObj.doctortname}</p>
                            </div>
                        );
                    })
                }

            </div>
        </>
    );

}

export default SuccessPage;