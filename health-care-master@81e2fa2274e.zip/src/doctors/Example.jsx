import React, { useEffect, useState, useRef } from "react";
import './DoctorList.css';
import { useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from 'react-redux';
import DisplayDoctor from "./DisplayDoctor"
import Header from "../components/header/Header"

function DoctorList() {

    const [seecardio, setSeeCardio] = useState(true);
    const [seeneuro, setSeeNeuro] = useState(true);
    const [seedermo, setSeeDermo] = useState(true);
    // const navigate = useNavigate();
  
    const ref = useRef(null)
    const ref1 = useRef(null)
  
    const ref2 = useRef(null)
  
    const handleClick = () => {
  
      ref.current?.scrollIntoView({ behavior: 'smooth' });
    };
  
    const handleClick1 = () => {
  
      ref1.current?.scrollIntoView({ behavior: 'smooth' });
    };
    const handleClick2 = () => {
  
      ref2.current?.scrollIntoView({ behavior: 'smooth' });
    };
    return (
      <div>
         <Header searchReq={true} />
  
        <div className="docmain">
          <div className="docspace"> 
          <div className="docabout">
            <p>Extensively experienced doctors for an intensive recovery</p>
            <p className="docabout1">Comprehensive healthcare services and state-of-the-art facilities at affordable costs.</p>
            <p className="hospital">~Yashoda Gives You Best❤️! </p>
          </div>
          </div>
          <h3 className="docheading">
            <p>
              Our Specialities
            </p>
  
          </h3>
          <div className="doccategory">
  
            {/* setSeeCardio((state)=>!state),setSeeNeuro(false), setSeeDermo(false) */}
            {/* , setSeeNeuro((state)=>!state), setSeeCardio(false), setSeeDermo(false)  */}
            {/* , setSeeDermo((state)=>!state), setSeeCardio(false), setSeeNeuro(false) */}
            <div className="cat1">
              <button onClick={handleClick} className="c1">
              </button>
              <pre   > Cardiology</pre> </div>
            <div className="cat1">
              <button onClick={handleClick1} className="c2">
              </button>
              <pre> Neurology</pre> </div>
            <div className="cat1">
              <button onClick={handleClick2} className="c3">
              </button>
              <pre>Dermatology</pre>
            </div>
            <div className="cat1">
              <button className="c4">
              </button> <pre>  Dentist</pre> </div>
  
            <div className="cat1">
              <button className="c5">
              </button> <pre>Orthopedics</pre> </div>
  
            <div className="cat1">
              <button className="c6">
              </button>  <pre>Physician</pre> </div>

              
  
          </div>
  
        
  
          {seecardio && <DisplayDoctor ref={ref} cat="cardio" role="Cardiologist" />}
          <div ref={ref1}>  {seeneuro && <DisplayDoctor cat="neuro" role="Neurologist" />} </div>
          <div ref={ref2}> {seedermo && <DisplayDoctor cat="dermo" role="Dermatologist" />} </div>
  
        </div>
      </div>
    )
  
  
  
  }
  
  
  export default DoctorList
  
  
  
  