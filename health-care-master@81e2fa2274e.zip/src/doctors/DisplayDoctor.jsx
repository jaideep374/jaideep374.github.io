import React, { useEffect, useState, useRef } from "react";
import './DoctorList.css';
import { useNavigate } from "react-router-dom";
import Header from '../components/header/Header';

function DisplayDoctor(props, ref) {

    const url = `http://localhost:1099/doctors?role=${props.role}`
    const [data, setData] = useState([])


    const navigate = useNavigate();

    const fetchInfo = () => {

        return fetch(url)
            .then((res) => res.json())
            .then((d) => setData(d))

    }

    useEffect(() => {
        fetchInfo()
    }, [])

    // useEffect(() =>{
    //     console.log(data)
    // },[data])

    // useEffect(()=>{
    //     console.log("data",data)
    // },[data])


    return (
        <>

            <div ref={ref} className="docdata"> <p className="doctext"> Department of {props.role}</p>
                <p>{console.log}</p>
                <div className="doccontainer">
                    {
                        data.map((dataObj, index) => {
                            function fun() {
                                navigate("/bookappoint", { state: { doctorname: dataObj.first_name, fee: dataObj.money, role: dataObj.role } })
                            }
                            function doctorprofile() {
                                navigate("/doctorProfile", { state: { doctorname: dataObj.first_name, fee: dataObj.money, role: dataObj.role,year: dataObj.year } })
                            }
                            return (
                                <div className="docbox">
                                    <div className="img-box" onClick={doctorprofile}>
                                        <img className="images" src={dataObj.link} alt="" />
                                    </div>
                                    <div className="bottom" onClick={doctorprofile}>
                                        <div className="b1" key={dataObj.id}>
                                            <br />
                                            <p className="docname">{dataObj.first_name}</p>
                                            <p className="docyear">{dataObj.year} years of experience overall</p>
                                            <br />
                                            <p className="role" onClick={doctorprofile}>{dataObj.role}</p>
                                        </div>
                                    </div>
                                    <div className='fee' onClick={doctorprofile}>
                                        <br />
                                        <p>₹{dataObj.money} Consultation Fee At Clinic </p>
                                    </div>
                                    <div className="docbook" onClick={fun}>Book Appointment</div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </>
    )
}


export default React.forwardRef(DisplayDoctor)