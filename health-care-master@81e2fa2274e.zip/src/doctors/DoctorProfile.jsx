import React from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { FaThumbsUp } from 'react-icons/fa6'
import { MdVerified } from 'react-icons/md';
import Header from "../components/header/Header";
import { ToastContainer, toast } from 'react-toastify';
import './Doctorprofile.css';
import 'react-toastify/dist/ReactToastify.css';



function DoctorProfile() {

    const location = useLocation();

    const doctor_name = location.state.doctorname;
    const fee = location.state.fee;
    const role = location.state.role;
    const year = location.state.year;
    // console.log(doctor_name, fee, role)


    // const ref = useRef();

    // const navigate = useNavigate();

    // const [doctortname, setDoctorname] = useState(doctor_name)
    // const [dfee, setDfee] = useState(fee);

    return (
        <>
        <Header/>
        <div className="docproappmain">
            <div className="docproappbox">
                <div className="docproappdoctor">
                    <div className="docproappdoctorinfo">
                        <div className="docproappimgbox">
                            <img className="appimg" src="https://th.bing.com/th/id/OIP.Yzu-EyLuD6Lxwym4zei4vAHaHW?pid=ImgDet&rs=1" alt="loading!" />
                        </div>

                        <div className="docprocontext">
                            <p className="name">{doctor_name}</p>
                            <p className="desc">BDS, MDS - Paedodontics And Preventive Dentistry</p>
                                <p className="desc">{role}</p>
                                <p className="desc"> {year} Years Experience Overall  ({year-2} years as specialist)
                            </p>


                            <div className="apphoslogo">
                                <img src="https://newsmeter.in/wp-content/uploads/2020/01/yashoda-hospital-fined-15-lakh-for-negligence.jpg" />
                            </div>
                            <div className="rating">
                                <MdVerified size={20} className="thumb" /> <p>Medical Registration Verified</p>
                            </div>
                            <br />
                            <div className="rating">
                                <FaThumbsUp size={20} className="thumb" />  <p className="t1">97%</p> <sub> (4357 votes)</sub>
                            </div>
                            <br /> <br />
                            <p className="desc">
                                {doctor_name} completed his post graduation in masters of dental surgery[ mds]
                                in the field of Pedodontics and preventive dentistry, from the esteemed Bapuji Dental College,
                                Davangere, a Karnataka, India. He is now serving as professor and HOD in the department of pediatric dentistry.
                            </p>
                            <br />
                            <p className="desc">
                                He is also a practicing implantology having completed his implant course from the prestigious Nobel Biocare, Sweden.
                                his keen interest in the field of implant dentistry has led him to accrue further certifications in this field.
                                He is also certified in complicated sinus lift implant procedures and advanced full mouth rehabilitation from Ossteum, Lisbon and Jakarta respectively.
                            </p>
                        </div>
                    </div>
                </div>
                <div className="question"> <p className="faq">FAQ</p>
                    <div className="answer">
                        <p className="que">Q: Where does {doctor_name} practice?</p>
                        <p className="ans">A: {doctor_name} practices at Chisel Dental - Koramangala.</p>
                    </div>
                    <div className="answer">
                        <p className="que">Q: Where does {doctor_name} practice?</p>
                        <p className="ans">A: {doctor_name} practices at Chisel Dental - Koramangala.</p>
                    </div>
                </div>
                <div className="facilities">
                    <div className="services"> <p>Services</p>
                        <ul className="service">
                            <li>Dental Fillings</li>
                            <li>Tooth Extraction</li>
                            <li>Teeth Whitening</li>
                            <li>Oral Rehabilitation</li>
                            <li>Crowns and Bridges Fixing</li>
                            <li>Dental Braces Fixing</li>
                            <li>Teeth - Jewellery</li>
                            <li>Tooth Restoration</li>
                            <li>Invisible/Clear Braces</li>
                            <li>Cosmetic/ Aesthetic Dentistry</li>
                        </ul>
                    </div>
                    <div className="special">
                        <div className="specializations"> <p>Specializations</p>
                            <ul className="sp1">
                                <li>Dentist</li>
                                <li>Implantologist</li>
                                <li>Pediatric Dentist</li>
                                <li>Cosmetic/Aesthetic Dentist</li>
                                <li>Preventive Dentistry</li>
                            </ul>
                        </div>
                        <div className="awards"> <p>Awards and Recognitions</p>
                            <ul className="aw1">
                                <li>Certified in Implants by Nobel Biocare - 2008</li>
                                <li>Certified Sinus Lift Implantologist by Ossteum - 2010</li>
                            </ul>
                        </div>
                    </div>
                    <div className="special">
                        <div className="specializations"> <p>Education</p>
                            <ul className="sp1">
                                <li>BDS - MS Ramaiah Dental College, Bangalore, 1999</li>
                                <li>MDS - Paedodontics And Preventive Dentistry - Bapuji college of dental sciences,Davangere, 2004</li>
                            </ul>
                        </div>
                        <div className="awards"> <p>Memberships</p>
                            <ul className="aw1">
                                <li>Indian Dental Association</li>
                                <li>Indian Society of Pediatric and Preventive Dentistry</li>
                                <li>Indian Society of Oral Implantologist</li>
                            </ul>
                        </div>
                    </div>
                    <div className="special">
                        <div className="specializations"> <p>Experience</p>
                            <ul className="sp1">
                                <li>2008 - 2016 Implantologist at Chisel dental clinics</li>
                                <li>2005 - 2009 Asst. Professor - Paediatric dentistry at Ambedkar College of Dental Sciences</li>
                                <li>2010 - 2013 Asso. Professor-Paediatric dentistry at SAIMS</li>
                            </ul>
                        </div>
                        <div className="awards"> <p>Registrations</p>
                            <ul className="aw1">
                                <li>9242A Karnataka State Dental Council, 2006</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            </>
    )
}

export default DoctorProfile
