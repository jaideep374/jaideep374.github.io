import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useState, useEffect } from "react";
import { Carousel } from 'react-responsive-carousel';
import { Sidebar, Menu, MenuItem} from 'react-pro-sidebar';
import { BsCalendarWeekFill } from 'react-icons/bs';
import { FaUserDoctor } from 'react-icons/fa6';
import { HiClipboardList } from 'react-icons/hi';
import Header from '../components/header/Header';
import Footer from '../components/footer/Footer';
import HospitalCarousel from '../components/card/HospitalCarousel';
import banner_1 from '../assets/banner_1.jpg';
import banner_2 from '../assets/banner_2.jpg';
import banner_3 from '../assets/banner_3.jpg';
import banner_5 from '../assets/banner_5.jpg';
import '../homePage/Book.css';
import "react-responsive-carousel/lib/styles/carousel.min.css";

const Landing = () => {
  const url = "http://localhost:1099/Hospital";
  const [hos, setHos] = useState([]);
  const fetchInfo = () => {
    return fetch(url)
      .then((res) => res.json())
      .then((d) => setHos(d))
  }
  useEffect(() => {
    fetchInfo()
  }, [])

  useEffect(() => {
    console.log(hos);
  }, [hos])
  const navigate = useNavigate();

  return (
    <div style={{ overflow: "hidden" }}>
      <Header searchReq={true} />
      <Carousel autoPlay infiniteLoop interval={2500} showThumbs={false} showArrows={false} showStatus={false} dynamicHeight={false}>
        <div>
          <img src={banner_1} alt='image1' />
        </div>
        <div>
          <img src={banner_2} alt='image2' />
        </div>
        <div>
          <img src={banner_3} alt='banner1' />
        </div>
        <div>
          <img src={banner_5} alt='banner1' />
        </div>
      </Carousel>

      <div className="side">
        <Sidebar rtl rootStyles={{
          borderRadius: '20px',
          background:
            'linear-gradient(0deg, #0F248D 0%, #0F248D 50%, #0F248D 100%)',
        }}>
          <Menu >

            {/* <MenuItem
              icon={<MenuOutlinedIcon />}
              onClick={() => {
                collapseSidebar();
              }}
              style={{ textAlign: "center" }}
            >
              {" "}

            </MenuItem> */}
            <Link to='/alldoctors'>
              <MenuItem icon={<BsCalendarWeekFill size={17} />} >
                Book Appointment
              </MenuItem>
            </Link>
            <Link to='/alldoctors'>
              <MenuItem icon={<FaUserDoctor size={20} />} >
                All Doctors
              </MenuItem>
            </Link>
            <Link to='/myappointments'>
              <MenuItem icon={<HiClipboardList size={23} />} >
                My Appointments
              </MenuItem>
            </Link>
          </Menu>
        </Sidebar>
      </div>

      <div>
        {/* <h1>Hospitals</h1> */}

        <HospitalCarousel></HospitalCarousel>

      </div>
      <Footer />
    </div>
  );
}
export default Landing