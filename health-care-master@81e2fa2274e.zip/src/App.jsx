import { useState } from 'react'
import { BrowserRouter,Routes,Route } from 'react-router-dom'
import Home from './homePage/Home'
import DoctorList from './doctors/Example'
import Profile from './profile/Profile'
import MyAppointments from './myappointments/MyAppointments'
import SignIn from './signin/SignIn'
import Appoint from './appointment/Appointment'
import DisplayAllDoctors from './displayAllDoctors/DisplayAllDoctors'
import Landing from './landingPage/Landing'
import About from './about/About'
import Contact from './Contact/Contact'
import DoctorProfile from './doctors/DoctorProfile'
import ProtectedRoute from './ProtectedRoute'
import './App.css'

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='' element={<Landing />}></Route>
          <Route path='/home' element={ <ProtectedRoute><Home /></ProtectedRoute>}></Route>
          <Route path='/signin' element={<SignIn/>}></Route>
          <Route path="/bookappoint" element={<ProtectedRoute><Appoint/></ProtectedRoute>}></Route>
          <Route path='/alldoctors' element={<DisplayAllDoctors/>}/>
          <Route path='/doctors' element={<DoctorList/>}></Route>
          <Route path='/about' element= {<About/>}></Route>
          <Route path='/profile' element={<ProtectedRoute><Profile/></ProtectedRoute>}></Route>
          <Route path='/myappointments' element={<ProtectedRoute> <MyAppointments /></ProtectedRoute>} />
          <Route path='/contact' element={<Contact />} />
          <Route path='/doctorProfile' element={ <DoctorProfile/>}/>
        </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
