import React from 'react'
import Header from '../components/header/Header'

const About = () => {
  return (
    <>
        <Header></Header>
        <div class='acontainer'>
            <h1 className='h1'>Our Mission</h1>
            <h4 className='h4'>CareConnect is on a mission to make quality healthcare affordable and accessible for over a billion+ Indians. We believe in 
                empowering our users with the most accurate, comprehensive, and curated information and care, enabling them to make better 
                healthcare decisions.</h4>
        </div>
    </>
  )
}

export default About