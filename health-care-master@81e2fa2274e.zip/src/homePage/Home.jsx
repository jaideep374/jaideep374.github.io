import React from 'react'
import { Sidebar, Menu, MenuItem, useProSidebar } from 'react-pro-sidebar';
import { Link, useNavigate } from 'react-router-dom';
import { BsCalendarWeekFill } from 'react-icons/bs';
import { FaUserDoctor } from 'react-icons/fa6';
import { HiClipboardList } from 'react-icons/hi';
import homeImg from '../assets/home-img.jpg'
import Header from '../components/header/Header'
import HospitalCarousel from '../components/card/HospitalCarousel'
import HomeAppCard from '../components/card/HomeAppCard'
import './Home.css'

const Home = () => {
    return (
        <>
            <Header searchReq={true}/>
            <section className='home-container'>
                <div className='home-text'>
                    <h1>Find your doctor and make an appointment</h1>
                    <p>Select preferred hosipital or doctor and time slot to book appointment.</p>
                    <div className='myappointments-home-card'>
                        <HomeAppCard/>
                    </div>
                    
                </div>
                
                <div className='home-img'>
                    <img src={homeImg} alt='homeimg'className='himg' />
                </div>
                
            </section>
            <div className="side">
        <Sidebar rtl rootStyles={{
          borderRadius: '20px',
          background:
            'linear-gradient(0deg, #0F248D 0%, #0F248D 50%, #0F248D 100%)',
        }}>
          <Menu >
            {/* <MenuItem
              icon={<MenuOutlinedIcon />}
              onClick={() => {
                collapseSidebar();
              }}
              style={{ textAlign: "center" }}
            >
              {" "}

            </MenuItem> */}
            <Link to='/alldoctors'>
              <MenuItem icon={<BsCalendarWeekFill size={17} />} >
                Book Appointment
              </MenuItem>
            </Link>
            <Link to='/alldoctors'>
              <MenuItem icon={<FaUserDoctor size={20} />} >
                All Doctors
              </MenuItem>
            </Link>
            <Link to='/myappointments'>
              <MenuItem icon={<HiClipboardList size={23} />} >
                My Appointments
              </MenuItem>
            </Link>
          </Menu>
        </Sidebar>
      </div>
      <div>
        <center><h1 style={{ fontSize: '50px' }}>Hospitals</h1></center>

        <HospitalCarousel></HospitalCarousel>


      </div>
        </>
    )
}

export default Home