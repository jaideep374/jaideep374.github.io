import React, { useEffect, useState } from 'react'
import axios from 'axios';
import { DialogActions, DialogContent, DialogContentText, DialogTitle, TextField } from '@mui/material';
import bcrypt from 'bcryptjs'
import Icon from "react-crud-icons";
import profilepic from '../../assets/profilepic.jpg';
import './ProfileNameUpdate.css'
import { Grid } from '@mui/material'
import { useDispatch, useSelector} from 'react-redux';
import { searchReducerActions } from '../search/searchReducer';


const ProfileNameUpdate = ({ setOpen, uid, email, password, userData }) => {
    const uname = (JSON.parse(localStorage.getItem('token-info'))).username;
    const [username, setUsername] = useState(uname);
    // const [password, setPassword] = useState('');
    const [profileImg, setProfileImg] = useState(userData.profilepicture);
    const [nemail, setNEmail] = useState(email);
    const [nphno, setNPhno] = useState(userData.phno);
    const [nmedication1, setNMedications1] = useState(userData.medication1);
    const [nmedication2, setNMedications2] = useState(userData.medication2);
    const [nbloodgroup, setNBloodgroup] = useState(userData.bloodgroup);
    const [nwbccount, setNWbccount] = useState(userData.wbccount);
    const [nrbccount, setNRbccount] = useState(userData.rbccount);
    const [nheight, setNHeight] = useState(userData.height);
    const [nweight, setNWeight] = useState(userData.weight);
    const [nconditions, setNConditions] = useState(userData.conditions);
    const [nbmi, setNBmi] = useState(userData.bmi);
    const [bmimessage, setBmiMessage] = useState(userData.bmimsg);
    const [promptStatus, setPromptStatus] = useState(false);
    const [error, setError] = useState('')
    //console.log(nbmi);
    const data = userData;
    const dispatch = useDispatch();
    const propUpdateDetails = useSelector(state => state.search.resultsProfile)
    const calculateBmi = () => {
        if (nheight && nweight) {
            const heightInMeters = nheight / 100;
            const bmi = (nweight / (heightInMeters * heightInMeters)).toFixed(2);
            setNBmi(bmi);
            let message = '';
            if (bmi < 18.5) {
                message = 'You are Underweight';
            } else if (bmi >= 18.5 && bmi < 25) {
                message = 'You are Normal weight';
            } else if (bmi >= 25 && bmi < 30) {
                message = 'You are Overweight';
            } else {
                message = 'You are Obese';
            }
            setBmiMessage(message);

        }
        else {
            setNBmi('');
            setBmiMessage('');
        }

    }
    const handleImageChange = (e) => {
        var reader = new FileReader();
        reader.readAsDataURL(e.target.files[0]);
        reader.onload = () => {
            // console.log(reader.result)
            setProfileImg(reader.result)
        };
        reader.onerror = error => {
            console.log("Error", error);
        };
    }
    const handleDelete = () => {
        setProfileImg("");
        // setPromptMsg(false);
        setPromptStatus(false);
    }
    const handleDeletePrompt = () => {
        setPromptStatus(true);
        // setRemoveButton("");        
    }


    useEffect(() => {
        calculateBmi();
    }, [nheight, nweight])



    const changeDetails = (e) => {
        e.preventDefault();

        const tempData = userData;
        console.log(tempData);
        axios.put(`http://localhost:1099/users/${uid}`, {

            username: uname,
            email: nemail,
            passwordHash: password,
            // passwordHash: bcrypt.hashSync(password, 10),
            profilepicture: profileImg,
            phno: nphno,
            bloodgroup: nbloodgroup,
            wbccount: nwbccount,
            rbccount: nrbccount,
            height: nheight,
            weight: nweight,
            bmi: nbmi,
            bmimsg: bmimessage,
            medication1: nmedication1,
            medication2: nmedication2,
            conditions: nconditions,

        })
        dispatch(searchReducerActions.setresultsProfile(!propUpdateDetails))
        // }

    }
    // console.log(userData)
    return (
        <>
            <form onSubmit={changeDetails} style={{ maxWidth: '100%', overflow: 'scroll' }}>
                <DialogTitle
                    sx={{
                        background: '',
                        width: '90%',
                        textAlign: 'center',
                        color: 'black',
                        overflowX: 'hidden',
                        // font: 'var(--headline-headline-4)',
                    }}>
                    Update User Details
                </DialogTitle>
                <hr></hr>
                <DialogContent >
                {/* {username !== '' ? <DialogContentText style={{ paddingLeft: '20px' }}>Username: {username}</DialogContentText> : <></>} */}
                    <Grid container spacing={2} >
                        <Grid container item xs={6} direction="column" >

                            
                            <DialogContent style={promptStatus ?{position:'relative',left:'5%',paddingTop:'0px',paddingBottom:'0px',overflowY:'hidden'} :{position:'relative',left:'5%'}}>
                                <div class="image-upload">
                                    <label for="file-input">
                                        <Icon name="edit" theme="light" />
                                    </label>
                                    <input id='file-input' accept='image/*' type='file' onChange={handleImageChange} style={{ display: 'none' }} />
                                    {profileImg ?
                                        <img src={profileImg} />
                                        :
                                        <img src={profilepic} alt='profilePic' />}
                                </div>
                                {
                                    promptStatus ?

                                        <div className='prompt'>
                                            <p><span>Are you Sure</span><br />You want to delete?</p>
                                            <button onClick={handleDelete} className='promptstatT'>Yes</button>
                                            <button onClick={() => { setPromptStatus(false) }} className='promptstatF' >No</button>

                                        </div>
                                        :
                                        <button onClick={handleDeletePrompt}>Remove Profile Pic</button>
                                }


                            </DialogContent>
                            <TextField
                                autoFocus
                                fullWidth
                                id="username"
                                label="Update Email"
                                margin="dense"
                                value={nemail}
                                onChange={(e) => setNEmail(e.target.value)}
                                placeholder="Username"
                                type="text"
                                variant="standard"
                            />
                            <br></br>
                            <TextField
                                className="notes-textarea"
                                fullWidth
                                label="Update PhoneNo"
                                margin="dense"
                                value={nphno}
                                onChange={(e) => setNPhno(e.target.value)}
                                placeholder="PhoneNo"
                                type="text"
                                variant="standard"
                            />
                            <br></br>
                            <TextField
                                className="notes-textarea"
                                fullWidth
                                label="Update Mediction 1"
                                margin="dense"
                                value={nmedication1}
                                onChange={(e) => setNMedications1(e.target.value)}
                                placeholder="Medication 1"
                                type="text"
                                variant="standard"
                            />
                            <br></br>
                            <TextField
                                className="notes-textarea"
                                fullWidth
                                label="Update Mediction 2"
                                margin="dense"
                                value={nmedication2}
                                onChange={(e) => setNMedications2(e.target.value)}
                                placeholder="Mediction 2"
                                type="text"
                                variant="standard"
                            />
                        </Grid>
                        <Grid container item xs={6} direction="column" >
                            {/* <div className='right-col'> */}
                                <br></br>
                                <TextField
                                    className="notes-textarea"
                                    fullWidth
                                    label="Update Bloodgroup"
                                    margin="dense"
                                    value={nbloodgroup}
                                    onChange={(e) => setNBloodgroup(e.target.value)}
                                    placeholder=""
                                    type="text"
                                    variant="standard"
                                />
                                <br></br>
                                <TextField
                                    className="notes-textarea"
                                    fullWidth
                                    label="Update Wbc-Count"
                                    margin="dense"
                                    value={nwbccount}
                                    onChange={(e) => setNWbccount(e.target.value)}
                                    placeholder="Wbc-Count"
                                    type="text"
                                    variant="standard"
                                />
                                <br></br>
                                <TextField
                                    className="notes-textarea"
                                    fullWidth
                                    label="Update Rbc-Count"
                                    margin="dense"
                                    value={nrbccount}
                                    onChange={(e) => setNRbccount(e.target.value)}
                                    placeholder="Rbc-Count"
                                    type="text"
                                    variant="standard"
                                />
                                <br></br>
                                <TextField
                                    className="notes-textarea"
                                    fullWidth
                                    label="Update Height"
                                    margin="dense"
                                    value={nheight}
                                    onChange={(e) => setNHeight(e.target.value)}
                                    placeholder="Height"
                                    type="number"
                                    variant="standard"
                                />
                                <br></br>
                                <TextField
                                    className="notes-textarea"
                                    fullWidth
                                    label="Update Weight"
                                    margin="dense"
                                    value={nweight}
                                    onChange={(e) => setNWeight(e.target.value)}
                                    placeholder="Weight"
                                    type="number"
                                    variant="standard"
                                />
                                <br></br>
                                <TextField
                                    className="notes-textarea"
                                    fullWidth
                                    label="Update Known Conditions"
                                    margin="dense"
                                    value={nconditions}
                                    onChange={(e) => setNConditions(e.target.value)}
                                    placeholder="Known Conditions"
                                    type="text"
                                    variant="standard"
                                />
                            {/* </div> */}


                        </Grid>


                    </Grid>
                </DialogContent>

                <DialogContentText
                    style={{
                        color: 'red',
                        textAlign: 'center',
                    }}>
                    {error}
                </DialogContentText>
                <DialogActions
                    style={{
                        justifyContent: 'center',
                        display: 'flex',
                        flexDirection: 'row',
                    }}>
                    <button className="profiledialog-update-button" onClick={() => setOpen(false)}> Update</button>
                    {/* <button type="blue" innerText="Update" buttonType="submit" /> */}
                </DialogActions>
            </form>
        </>
    )
}
export default ProfileNameUpdate