import React from 'react'
import { useDispatch } from 'react-redux';
import './RoleFilterCard.css'
import { useNavigate } from 'react-router-dom';
import { setFilter } from '../search/searchReducer';

const RoleFilterCard = ({allDoctorsReq}) => {
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const handleRoles = (e) => {
        const temp = e.target.value;
        dispatch(setFilter({ temp }))
        // document.button.style.background = '#0F248D';
        navigate('/alldoctors')
    }
    return (
        <div className='card-specializations-body'>
            {
                allDoctorsReq ? " " :
                <div className='card-head'>
                    <h4>You haven't made a doctor's appointment yet. It's important to prioritize your health. Schedule an appointment
                        by selecting the specialization of your choice.</h4>
                </div>
            }
            <div className='card-specializations-content'>
                <button className="card-specializations-buttons" value='Cardiologist' onClick={handleRoles}>Cardiology</button>
                <button className="card-specializations-buttons" value='Neurologist' onClick={handleRoles}>Neurology</button>
                <button className="card-specializations-buttons" value='Dermatologist' onClick={handleRoles}>Dermatology</button>
                <button className="card-specializations-buttons" value='Dentist' onClick={handleRoles}>Dentist</button>
                <button className="card-specializations-buttons" value='Orthopedics' onClick={handleRoles}>Orthopedics</button>
                <button className="card-specializations-buttons" value='Physician' onClick={handleRoles}>Physician</button>
                {
                    allDoctorsReq
                     ? <button className="card-specializations-buttons" value='' onClick={handleRoles}>Reset</button>
                     : ""
                    
                }
                
            </div>
        </div>
    )
}

export default RoleFilterCard