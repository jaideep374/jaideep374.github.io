import React from "react";
import classNames from "classnames";
import { AiFillHeart, AiFillStar } from "react-icons/ai";
import { BsChatSquareFill, BsFillStarFill } from "react-icons/bs";
import styles from "./Card.module.css";

const Card = ({ title, likes, ratings, image, location, category }) => {
    console.log(likes);
    return (
        <>
            <div className={classNames([styles.wrapper, styles.wrapperAnime])}>


                <div className={styles.header}>
                    <div className={styles.imageWrapper}>
                        <img src={image} className={styles.image} alt="" />
                    </div>
                    <div className={styles.badgeWrapper}>
                        <div
                            className={classNames([
                                styles.primaryBadge,
                                styles.badgeAnime,
                                "group",
                            ])}
                        >
                            <BsFillStarFill />
                            <span
                                className={classNames([styles.counter, "group-hover:text-white"])}>
                                {likes} ({ratings} Ratings)
                            </span>
                        </div>
                    </div>
                </div>
                <div className={styles.textWrapper}>
                    <h1 className={styles.text}>{`${title}`}</h1>
                </div>
                <div className={styles.paraWrapper}>
                    <p>Location  : {`${location}`}</p>
                </div>
            </div>
        </>
    );
};

export default Card;