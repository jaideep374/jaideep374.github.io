import { useState, useEffect } from "react";
import Carousel from "react-multi-carousel";
import "react-multi-carousel/lib/styles.css";
import React from 'react'
import Card from "./Card";
import './HospitalCarousel.css'
import { useNavigate } from "react-router-dom";

const HospitalCarousel = () => {
    const url = "http://localhost:1099/Hospital";
    const [hos, setHos] = useState([]);
    const navigate = useNavigate();
    const fetchInfo = () => {
        return fetch(url)
            .then((res) => res.json())
            .then((d) => setHos(d))
    }
    useEffect(() => {
        fetchInfo()
    }, [])

    // useEffect(() => {
    //     console.log(hos);
    // }, [hos])
    const responsive = {
        superLargeDesktop: {
            breakpoint: { max: 4000, min: 3000 },
            items: 5
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 4
        },
        tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 2
        },
        mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1
        }
    };

    return (
        <div className="hospital-cards">
            <Carousel responsive={responsive}>
                {
                    hos.map((element, index) => (
                        <div className='cardclick' onClick={() => { navigate('/doctors')}}>
                            <Card
                                key={index}
                                title={element.hospital_name}
                                likes={element.likes}
                                ratings={element.rating}
                                image={element.link}
                                location={element.location}
                                category={element.category}
                            />
                        </div>

                    ))}
            </Carousel>
        </div>


    );
}

export default HospitalCarousel
