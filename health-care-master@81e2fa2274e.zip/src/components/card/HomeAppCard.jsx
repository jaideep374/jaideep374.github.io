import { useState, useEffect } from "react";
import axios from "axios";
import { FaUserDoctor, FaLocationDot } from 'react-icons/fa6';
import { FaNotesMedical } from 'react-icons/fa';
import { HiCalendarDays } from 'react-icons/hi2';
import { useNavigate } from "react-router-dom";
import { useDispatch } from "react-redux";
import RoleFilterCard from "./RoleFilterCard";
import './HomeAppCard.css'

function HomeAppCard() {
  const userlogged = (JSON.parse(localStorage.getItem('token-info'))).username;
  const navigate = useNavigate();
  const [slotData, setSlotData] = useState([]);
  const fetchSlots = async () => {
    const allSlots = await axios.get(`http://localhost:1099/slots?uname=${userlogged}`);
    setSlotData(allSlots.data);
  }
  slotData.sort((a, b) => { return b.id - a.id });
  const appHome = slotData.slice(0, 1);
  useEffect(() => {
    fetchSlots();

  }, [])
  
  return (
    <div className='card-container'>
      <div className='card-head'>
        <h2>Active Appointments</h2>
        
      </div>
      {
        appHome == "" ?
          <RoleFilterCard allDoctorsReq={false} />
          :
          appHome.map((dataObj) => {
            let date = dataObj.date
            const parts = date.split('-')
            let dates = parts[2] + '/' + parts[1] + '/' + parts[0].slice(2)
            return (
              <div className='card-body'>
                <div className='card-content-outer'>
                  <FaUserDoctor className="outer-icon" />
                  <div className="card-content-inner">
                    <h5>Doctor</h5>
                    <h4>{dataObj.doctorname}</h4>
                  </div>
                </div>
                <div className='card-content-outer-date'>
                  <HiCalendarDays className="outer-icon" />
                  <div className="card-content-inner">
                    < h5>Appointment </h5>
                    <h4>
                      {dates} - {dataObj.time.slice(0, 2) >= 12 ? (parseInt(dataObj.time.slice(0, 2)) == 12 ? parseInt(dataObj.time.slice(0, 2)) : parseInt(dataObj.time.slice(0, 2) - 12)) + ":" + (dataObj.time.slice(3, 5)) + " pm" : dataObj.time.slice(0, 2) + ":" + dataObj.time.slice(3, 5) + " am"}
                    </h4>
                  </div>
                </div>
                <div className='card-content-outer'>
                  <FaNotesMedical className="outer-icon" />
                  <div className="card-content-inner">
                    <h5>Purpose</h5>
                    <h4>{dataObj.health}</h4>
                  </div>
                </div>
                <div className='card-content-outer'>
                  <FaLocationDot className="outer-icon" />
                  <div className="card-content-inner">
                    <h5>Location</h5>
                    <h4>Raidurgam</h4>
                  </div>
                </div>
                <button className="view-more-app-button" onClick={() => navigate('/myappointments')}>View All </button>
              </div>
            )
          })
      }
      <div className="view-more-app-button-outer">
      
      </div>
     
    </div>
  );
}

export default HomeAppCard;