import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import TextField from "@mui/material/TextField";
import { FaSearch } from "react-icons/fa";
import SearchIcon from "@mui/icons-material/Search";
import { useDispatch } from 'react-redux';
import { setQuery } from './searchReducer'
import './searchBox.css'
import { Input } from '@mui/material';
/*state variable
use state etc..
functions (order of imports)
*/

export const SearchBox = () => {
  const [searchInput, setSearchInput] = useState("");
  const navigate=useNavigate()
  const dispatch = useDispatch()
  // const [prompt,setPrompt]=useState("")
  const searchHandle = (e) => {
    e.preventDefault();
    dispatch(setQuery({ searchInput }))
    navigate('/alldoctors')
  }

  return (
    <div className='searchBox'>
      <form onSubmit={searchHandle} className='search'>
        <Input type='text' className='searchInputs' placeholder='Search Doctors' value={searchInput} onChange={(e) => setSearchInput(e.target.value)}/>
      <button type="submit" className='searchButton'><SearchIcon size="small" /></button>
      </form>
      </div>

    
  );
};




export default SearchBox;