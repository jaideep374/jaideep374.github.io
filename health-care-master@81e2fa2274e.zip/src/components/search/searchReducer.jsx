import { createSlice } from "@reduxjs/toolkit";
import axios from "axios";
import { createAsyncThunk } from "@reduxjs/toolkit";
 

export const searchReducer = createSlice({
    name: 'search',
    initialState: {
        searchTerm: {
            value: ""
        },
        filterTerm: {
            value: ""
        },

        doctors: [],
        status: 'idle',
        resultsProfile:false,
        error: null
    },

    reducers: {
        setQuery: (state, action) => {
            state.searchTerm.value = action.payload.searchInput
            
        },
        setFilter: (state, action) => {
            state.filterTerm.value = action.payload.temp
            
        },
        setresultsProfile: (state, action) => {
            state.resultsProfile = action.payload
            console.log("hello")
        }
    },

    // extraReducers: (builder) => {
    //     builder
    //         .addCase(fetchResults.pending, (state) => {
    //             state.status = "loading";
    //         })

    //         .addCase(fetchResults.fulfilled, (state, action) => {
    //             state.status = "succeeded";
    //             state.doctors = action.payload;

    //         })

    //         .addCase(fetchResults.rejected, (state, action) => {
    //             state.status = "failed";
    //             state.error = action.error.message;
    //         });

    // }

}
);
export const { setQuery } = searchReducer.actions;
export const { setFilter } = searchReducer.actions;
export const searchReducerActions = searchReducer.actions;
export default searchReducer.reducer;