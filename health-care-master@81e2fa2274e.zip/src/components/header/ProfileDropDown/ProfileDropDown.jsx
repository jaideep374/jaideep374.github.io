import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { CgProfile } from "react-icons/cg";
import { BiLogIn } from 'react-icons/bi';
import './ProfileDropDown.css'

const ProfileDropDown = () => {
  const [showBox, setShowbox] = useState(true);

  const navigate = useNavigate();
  const handleshow = () => {

    setShowbox(true);

  };

  // console.log(userD);
  const handlelogout = () => {
    navigate('/landing');
    localStorage.removeItem('token-info');
    // setIsLoggedin(false);

  }
  var exist = "false";
  try {
    const uname = (JSON.parse(localStorage.getItem('token-info'))).username;
    exist = true;
  }
  catch {
    exist = false
  }


  return (
    <>
      {/* <div className="dropdown">
                  <button className="CgProfile">{<CgProfile size={40} />}</button>
          <div className="dropdown-content">
            <ul>
              <li>
                <Link to="/profile">My Profile</Link>
              </li>
              <li>
                <Link to="/logout">Logout</Link>
              </li>
            </ul>  
          </div>
        </div> */}
      <div className="dropdown" onMouseOver={handleshow} >

        <button className="CgProfile" onClick={(exist) => { exist ? navigate("/profile") : navigate("/signin") }}> {exist ? (<CgProfile size={35} />) : <BiLogIn size={35} />} </button>
        {exist ? (
              <div className = "dropdown-content" >
                <div id='pp'>
                  <h2 onClick={() => navigate("/profile")}>Profile</h2>
                </div>
                <div id='pp'>
                <h2 onClick={handlelogout}>Logout</h2>
                </div>
              </div>
            ) : ""}
    </div >
    </>
  )
}

export default ProfileDropDown