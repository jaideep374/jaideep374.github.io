import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./header.css";
import { FaBars } from "react-icons/fa";
import { ImCross } from "react-icons/im";
import applogo from "../../assets/applogo.png";
import { CgProfile } from "react-icons/cg";
import { BiLogIn } from "react-icons/bi";
import SearchBox from "../search/searchBox";
import Profile from "../../profile/Profile";
import ProfileDropDown from "./ProfileDropDown/ProfileDropDown";


const Header = ({ searchReq }) => {
  const [Mobile, setMobile] = useState(false);

  return (
    <nav className="navbar">
      <div className="navbarLogo">
        <Link to = "/home">
          <img src={applogo} alt="CareConnect" width="175" height="80" />
          </Link>
      </div>
      <div className="searchBar">
      {searchReq ? (<SearchBox></SearchBox>) : ""}
      </div>
      <ul className={Mobile ? "nav-links-mobile" : "nav-links"} onClick={() => setMobile(false)}>
        <div className="navbarLink">
          <div className="navbarclosed">
            <Link to="/profile">
              <li>Profile</li>
            </Link>
          </div>
          <Link to="/home">
            <li >Home</li>
          </Link>
          {/* <Link to="/about">
            <li>About</li>
          </Link> */}
          <Link to="/contact">
            <li>Contact</li>
          </Link>
          <div className="navbarclosed">
            <Link to="/myappointments">
              <li>My Appointments</li>
            </Link>
          </div>
        </div>
        {/* <Link to="/Profile"> */}
        <li>
          <ProfileDropDown />
        </li>
        {/* </Link> */}
      </ul>
      <button className="mobile-menu-icon" onClick={() => setMobile(!Mobile)}>
        {Mobile ? <ImCross /> : <FaBars />}
      </button>
    </nav>
  );
};



export default Header;

