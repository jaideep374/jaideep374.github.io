import { Sidebar, Menu, MenuItem} from "react-pro-sidebar";
import { BsCalendarWeekFill } from 'react-icons/bs';
import { FaUserDoctor } from 'react-icons/fa6';
import { HiClipboardList } from 'react-icons/hi';
import { useNavigate } from "react-router-dom";

function SideBarProfile() {
  const navigate = useNavigate();
  const handleBookAppointment = () => {
    navigate('/alldoctors')
  }
  const handleAppointment = () => {
    navigate('/myappointments')
  }
  const handleAllDoctors = () => {
    navigate('/alldoctors')
  }
  return (
    <div id="app" style={({ height: "100vh" }, { display: "flex" })}>
      <Sidebar style={{ height: "100vh", margin:"none !important"}}>
        <Menu>
          <MenuItem icon={<BsCalendarWeekFill/>} onClick={handleBookAppointment}>Book Appointment</MenuItem>
          <MenuItem icon={<HiClipboardList/>} onClick={handleAppointment}>My Appointments</MenuItem>
          <MenuItem icon={<FaUserDoctor />} onClick={handleAllDoctors}>All Doctors</MenuItem>
          
        </Menu>
      </Sidebar>
    
    </div>
  );
}

export default SideBarProfile;