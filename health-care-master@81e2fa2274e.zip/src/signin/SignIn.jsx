import React, { useState, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom'
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faUser, faLock, faEnvelope, faCalendar, faPhone } from '@fortawesome/free-solid-svg-icons';
import { faGoogle, faLinkedinIn } from '@fortawesome/free-brands-svg-icons';
import { ToastContainer, toast } from 'react-toastify';
import axios from 'axios';
import './SignIn.css';
import 'react-toastify/dist/ReactToastify.css';
import bcrypt from 'bcryptjs'
import SignUpImage from '../assets/SignUpImage.png'
import SignInImage from '../assets/SignInImage.png'
import Header from '../components/header/Header';

function SignIn() {
    const [isSignUpMode, setIsSignUpMode] = useState(false);
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const [email, setEmail] = useState("");
    const [cpassword, setCPassword] = useState("");
    const [phno, setPhno] = useState("");
    const [users, setUsers] = useState([]);
    const [isLoggedin, setIsLoggedin] = useState(false);
    const navigate = useNavigate();
    const handleSignUpClick = () => {
        setIsSignUpMode(true);
    };
    const handleSignInClick = () => {
        setIsSignUpMode(false);
    };
    const loginhandler = async (e) => {
        e.preventDefault();
        if (!username || !password)
            return toast.error("Please enter your credentials");
        try {
            const allUsersL = await axios.get('http://localhost:1099/users',
                { params: { username } },
            )
            console.log(allUsersL)
            const user = allUsersL.data[0];
            if (!user)
                return toast.error("Sorry, we can't find an account with this username. Please try again or create a new account")
            const passwordMatch = await bcrypt.compare(password, user.passwordHash)
            if (!passwordMatch)
                return toast.error("Please verify your Password")
            const passHash = user.passwordHash;
            const userData = {
                username,
                passHash
            }
            localStorage.setItem('token-info', JSON.stringify(userData));
            setUsername("");
            setPassword("");
            navigate("/home");
        }
        catch (error) {
            console.log(error)
        }
    }

    const registerHandle = async (e) => {
        const regex =  new RegExp("(?:(?:\\+|0{0,2})91(\\s*[\\-]\\s*)?|[0]?)?[789]\\d{9}", "g");;
        const validationPhno =phno.match(regex);
        console.log(validationPhno);
        try {
            e.preventDefault();
            if (password.length < 8)
                return toast.error("Password must contain minimum 8 characters")
            else if (password !== cpassword)
                return toast.error("Password is mismatched")
            else if (!(phno.match(regex)))
                return toast.error("Phone number is not valid, Please check.")
            else {
                const allUsersR = await axios.get('http://localhost:1099/users',
                    {
                        params: { username: username.value },  //username is unique
                    });
                console.log(allUsersR)
                const existingUser = allUsersR.data.filter( //filtering based on the username
                    (user) => user.username === username
                );
                const existingEmail = allUsersR.data.filter( //filtering based on the email
                    (user) => user.email === email
                );
                if (existingUser.length || existingEmail.length) //check if the username or email is already present in the db
                    return toast.error("User already exists");
                const saltRounds = 10;
                const passwordHash = bcrypt.hashSync(password, saltRounds);
                console.log(username)
                const userDa = {
                    username,
                    email,
                    passwordHash,
                    phno,
                    profilepicture: '',
                    bloodgroup: 'Type',
                    wbccount: '',
                    rbccount: '',
                    height: 0,
                    weight: 0,
                    bmi: 0,
                    bmimsg: '',
                    medication1: 'Medication 1',
                    medication2: 'Medication 2',
                    conditions:'None',
                };
                const response = await axios.post('http://localhost:1099/users', userDa); //posting all the data into db
                const user = { ...response.data, id: response.data.id };
                const userData = {
                    username,
                    passwordHash,
                    phno,
                };
                localStorage.setItem('token-info', JSON.stringify(userData));
                setUsername("");
                setEmail("");
                setPassword("");
                setCPassword("");
                setPhno("");
                navigate('/home');
            }
        }
        catch (error) {
            console.log(error);
        }
    }


    return (
        <>
            <Header searchReq={false} />
            <div className={`loginContainer ${isSignUpMode ? 'sign-up-mode' : ''}`}>
                <div className="forms-container">
                    <div className="signin-signup">
                        <form onSubmit={loginhandler} className="sign-in-form loginForm">
                            <h2 className="title">Sign in</h2>
                            <div className="input-field">
                                <a className='icon'>
                                    <FontAwesomeIcon icon={faUser} height={100} width={50} />
                                </a>
                                <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} id="user" />
                            </div>
                            <div className="input-field">
                                <a className='icon'>
                                    <FontAwesomeIcon icon={faLock} height={100} width={50} />
                                </a>
                                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} id="pass" />
                            </div>
                            <input type="submit" value="Login" className="btn solid" />

                            <p className="social-text loginp"> Sign in with social platforms</p>
                            <div className="social-media">

                                <a href="#" className="social-icon">
                                    <FontAwesomeIcon icon={faGoogle} className='my-auto mx-auto' />
                                </a>
                                <a href="#" className="social-icon">
                                    <FontAwesomeIcon icon={faLinkedinIn} className='my-auto mx-auto' />
                                </a>
                            </div>
                        </form>
                        <ToastContainer />







                        <form onSubmit={registerHandle} className="sign-up-form loginForm">
                            <h2 className="title">Sign up</h2>
                            <div className="input-field">
                                <a className='icon'>
                                    <FontAwesomeIcon icon={faUser} height={100} width={50} />
                                </a>
                                <input type="text" placeholder="Username" id="user" value={username} onChange={(e) => setUsername(e.target.value)} required />
                            </div>
                            <div className="input-field">
                                <a className='icon'>
                                    <FontAwesomeIcon icon={faEnvelope} height={100} width={50} />
                                </a>
                                <input type="email" placeholder="Email" id="email" value={email} onChange={(e) => setEmail(e.target.value)} />
                            </div>
                            <div className="input-field">
                                <a className='icon'>
                                    <FontAwesomeIcon icon={faLock} height={100} width={50} />
                                </a>
                                <input type="password" placeholder="Password" id="pass" value={password} onChange={(e) => setPassword(e.target.value)} required />
                            </div>
                            <div className="input-field">
                                <a className='icon'>
                                    <FontAwesomeIcon icon={faLock} height={100} width={50} />
                                </a>
                                <input type="password" placeholder="Confirm Password" id="cpass" value={cpassword} onChange={(e) => setCPassword(e.target.value)} required />
                            </div>
                            {/* <div className="input-field">
                            <a className='icon'>
                                <FontAwesomeIcon icon={faCalendar} height={100} width={50} />
                            </a>
                            <input type="date" placeholder="DOB" id='date' name="dob" />
                        </div> */}
                            <div className="input-field">
                                <a className='icon'>
                                    <FontAwesomeIcon icon={faPhone} height={100} width={50} />
                                </a>
                                <input type="tel" placeholder="Phone Number" value={phno} onChange={(e) => setPhno(e.target.value)} min="10" max="10" id="telep" required />
                            </div>
                            <input type="submit" value="SignUp" className="btn solid s" />

                            <p className="social-text loginp">Or Sign up with social platforms</p>
                            <div className="social-media">

                                <a href="#" className="social-icon">
                                    <FontAwesomeIcon icon={faGoogle} className='my-auto mx-auto' />
                                </a>
                                <a href="#" className="social-icon">
                                    <FontAwesomeIcon icon={faLinkedinIn} className='my-auto mx-auto' />
                                </a>
                            </div>
                        </form>
                        <ToastContainer />
                    </div>
                </div>
                <div className="panels-container">
                    <div className="panel left-panel">
                        <div className="contentLogin">
                            <h3 className='loginh3'>Care Connect</h3>
                            <p className='loginp'>New here?</p>
                            <button className="btn transparent" onClick={handleSignUpClick}>
                                Sign up
                            </button>
                            <img src={SignInImage} className="image lpanel" alt="not found" />
                        </div>
                        <img src="/img/dogLogin1.svg" className="image" alt="" />
                    </div>
                    <div className="panel right-panel">
                        <div className="contentLogin">
                            <h3 className='loginh3'>Care Connect</h3>
                            <p className='loginp'>Already a member?
                            </p>
                            <button onClick={handleSignInClick} className="btn transparent" id="sign-in-btn">
                                Sign in
                            </button>
                            <img src={SignUpImage} className="image rpanel" alt="not found" />
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default SignIn