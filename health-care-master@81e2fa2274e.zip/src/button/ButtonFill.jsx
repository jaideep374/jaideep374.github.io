import React from 'react'
import { useNavigate } from 'react-router-dom'

const ButtonFill = ({nvalue,bcolor,handleButtonEvent,bheight,bwidth}) => {
    const navigate = useNavigate();
    
  return (
    <div className='button-container'>
        <button className='button-fill' style={{backgroundColor:{bcolor}, height:{bheight}, width:{bwidth}} } onClick={handleButtonEvent}>
            {nvalue}
        </button>
    </div>
  )
}

export default ButtonFill