
import React, { useEffect, useState } from "react";
import './MyAppointments.css';
import Header from "../components/header/Header";
import Footer from "../components/footer/Footer";
import { MDBCard, MDBCardImage } from "mdb-react-ui-kit"
import axios from "axios";
import myappoint_bg from "../assets/myappointments_bg.jpg"
import SideBarProfile from "../components/sideBar/SideBarProfile";
export default function MyAppointments() {


    const us = JSON.parse(localStorage.getItem('token-info'));
    const uname = us.username;
    // console.log(uname);
    const [slotData, setSlotData] = useState([]);
    const oldA = "Visited";
    const newA = "Upcoming";
    const fetchSlots = async () => {
        const allSlots = await axios.get(`http://localhost:1099/slots?uname=${uname}`);
        setSlotData(allSlots.data);
    }
    slotData.sort((a, b) => { return b.id - a.id });
    useEffect(() => {
        fetchSlots();

    }, [])
    console.log("hello")
    return (
        <>
            <Header searchReq={false} />
            <div className="acontainer">
                <div className="project">
                    <SideBarProfile className="checktest" />

                    <div className="cardalign">
                        <div className="myappointment-bg">
                            <img src={myappoint_bg} alt="appointment-bg" style={{ margin: '0px' }} />
                        </div>
                        <div className="myappointment-top" >
                            <h2>My Appointments</h2>
                            <div className="AppointMobileView">
                                <div className="myappointment-head" >
                                    <h3>Doctor</h3>
                                    <h3>Patient</h3>
                                    <div className="AppoointMobilVeiw">
                                        <h3>Status</h3>
                                    </div>
                                    <h3>Appointment </h3>
                                    <div className="AppointMobileView">
                                        <h3>Phone</h3>
                                    </div>
                                    <h3>Fee</h3>
                                </div>
                            </div>
{/* 
                            <div className="AppointMobileView">
                                <div className="myappointment-head" >
                                    <h3 style={{ paddingLeft: "3%", paddingRight: "40px" }}>Doctor</h3>
                                    <h3 style={{ paddingLeft: "5%", paddingRight: "3%" }}>Patient</h3>
                                    <div className="AppoointMobilVeiw">
                                        <h3 style={{ paddingLeft: "7%" }}>Status</h3>
                                    </div>
                                    <h3 style={{ paddingRight: "6%" }}>Appointment </h3>
                                    <div className="AppointMobileView">
                                        <h3 style={{ paddingRight: "4%" }}>Phone</h3>
                                    </div>
                                    <h3 style={{ paddingLeft: "9%" }}>Fee</h3>
                                </div>
                            </div> */}
                        </div>
                        {
                            slotData.map((dataObj) => {
                                let date = dataObj.date
                                const parts = date.split('-')
                                let dates = parts[2] + '/' + parts[1] + '/' + parts[0].slice(2)
                                return (
                                    // eslint-disable-next-line react/jsx-key
                                    <div className="card">
                                        <div className="myappointment-data">
                                            <div className="myappointment-doctor-data">
                                                <MDBCard style={{ width: "4rem", height: "5rem", padding: "0px", margin: "0px", position: "relative", left: '0%' }}>
                                                    <MDBCardImage src={dataObj.img} fluid alt="Doctor" style={{ position: "relative", left: '0%' }} />
                                                </MDBCard>
                                                <h4 style={{ fontWeight: 'bolder' }}>{dataObj.doctorname}</h4>
                                            </div>
                                            <div className="myappointment-patient-data">
                                                <h4 style={{ fontWeight: 'bolder', width: '20%' }}>{dataObj.pname}</h4>
                                                <div className="AppointMobileView">
                                                    {
                                                        dataObj.status ?
                                                            <h4><button className="button-status-revisit">{oldA}</button></h4>
                                                            :
                                                            <h4><button className="button-status-consult">{newA}</button></h4>
                                                    }
                                                </div>
                                                <h4 style={{ fontWeight: 'bolder' }}>{dates}<br /><span style={{ fontWeight: 'lighter' }}></span></h4>
                                                <div className="AppointMobileView">
                                                    <h4 style={{ fontWeight: 'bolder' }}>{dataObj.pno}</h4>
                                                </div>
                                                <h3 style={{ fontWeight: 'bolder' }}>₹{dataObj.dfee}</h3>
                                            </div>
                                            <div className="ShowMobileView">
                                                <div className="myappointment-patient-data">
                                                    <h4 style={{ fontWeight: 'bolder' }}>{dataObj.pno}</h4>
                                                    <h4 style={{ fontWeight: 'bolder' }}>{dataObj.time}<br /><span style={{ fontWeight: 'lighter' }}></span></h4>
                                                    {
                                                        dataObj.status ?
                                                            <h4><button className="button-status-revisit">{oldA}</button></h4>
                                                            :
                                                            <h4><button className="button-status-consult">{newA}</button></h4>
                                                    }
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                )
                            })
                        }
                    </div>
                </div>
            </div>
            {/* <Footer></Footer> */}
        </>
    );
}