import { useEffect, useState} from 'react';
import './DisplayAllDoctors.css';
import { useSelector, useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import Header from '../components/header/Header';
import RoleFilterCard from '../components/card/RoleFilterCard';
function DisplayAllDoctors() {

    const prompt = useSelector(state => state.search.searchTerm.value)
    const prompt1 = useSelector(state => state.search.filterTerm.value)
    const url = `http://localhost:1099/doctors`;
    const [data, setData] = useState([])

    const navigate = useNavigate();

    const fetchDoctorsData = () => {
        return fetch(url)
            .then((res) => res.json())
            .then((d) => setData(d));
    }

    useEffect(() => {
        // console.log("me")
        fetchDoctorsData()
    }, [])

    
    const searchResults = data.filter((d) => {
        return d.first_name.toLowerCase().includes(prompt.toLowerCase())
    })
    const roleBasedSearchResults = data.filter((d) => {
        return d.role.toLowerCase().includes(prompt1.toLowerCase())
    })
    console.log(roleBasedSearchResults);
    return (
        <>
            <Header searchReq={true} />
            <div className="alldoccontainer">
                <div className='filter-card-doctors'>
                    <RoleFilterCard allDoctorsReq={true}/>
                </div>
                
                {
                    prompt =="" 
                    ?
                    roleBasedSearchResults.map((dataObj, index) => {

                        function fun() {
                            navigate("/bookappoint", { state: { doctorname: dataObj.first_name, fee: dataObj.money, role: dataObj.role } })
                        }
                        return (
                            <div className="alldocbox">
                                <div className="alldoc-img-box">
                                    <img className="alldocimages" src={dataObj.link} alt="" />
                                </div>
                                <div className="alldocbottom" >
                                    <div className="alldocb1" key={dataObj.id}>
                                        <br />
                                        <p style={{ fontSize: "25px", color: "darkblue" }}>{dataObj.first_name}</p>
                                        <p style={{ fontSize: "15px", color: "gray" }}>{dataObj.year} years of experience overall</p>
                                        <br />
                                        <p className="alldocrole" style={{ fontSize: "18px", fontWeight: "bold" }}>{dataObj.role}</p>
                                    </div>
                                </div>
                                <div className='fee'>
                                    <br />
                                    <p>₹{dataObj.money} Consultation Fee At Clinic </p>
                                </div>
                                <div className="alldocbook">
                                    <button onClick={fun} className='bok'> <p>Book Appointment</p> </button>
                                </div>
                            </div>
                        )
                    })
                    :
                    searchResults.map((dataObj, index) => {

                        function fun() {
                            navigate("/bookappoint", { state: { doctorname: dataObj.first_name, fee: dataObj.money, role: dataObj.role } })
                        }
                        return (
                            <div className="alldocbox">
                                <div className="alldoc-img-box">
                                    <img className="alldocimages" src={dataObj.link} alt="" />
                                </div>
                                <div className="alldocbottom" >
                                    <div className="alldocb1" key={dataObj.id}>
                                        <br />
                                        <p style={{ fontSize: "25px", color: "darkblue" }}>{dataObj.first_name}</p>
                                        <p style={{ fontSize: "15px", color: "gray" }}>{dataObj.year} years of experience overall</p>
                                        <br />
                                        <p className="alldocrole" style={{ fontSize: "18px", fontWeight: "bold" }}>{dataObj.role}</p>
                                    </div>
                                </div>
                                <div className='fee'>
                                    <br />
                                    <p>₹{dataObj.money} Consultation Fee At Clinic </p>
                                </div>
                                <div className="alldocbook">
                                    <button onClick={fun} className='bok'> <p>Book Appointment</p> </button>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
            
        </>
    );
}
export default DisplayAllDoctors