import React, { Suspense, useEffect, useState } from 'react'
import Header from '../components/header/Header'

import '@fortawesome/fontawesome-free/css/all.min.css';
import './Profile.css'
import profilepic from '../assets/profilepic.jpg'
import Footer from '../components/footer/Footer';
import ProfileNameUpdate from '../components/profileUpdate/ProfileNameUpdate';
import { Dialog } from '@mui/material';
import SideBarProfile from '../components/sideBar/SideBarProfile';
import { useNavigate } from 'react-router-dom';
import {MdEmail} from 'react-icons/md'
import {BsFillTelephoneFill} from 'react-icons/bs'
import { FaLocationDot } from 'react-icons/fa6'
import { useSelector } from 'react-redux';


const Profile = () => {
  const propUpdateDetails = useSelector(state => state.search.resultsProfile)
  const [nbmi, setNBmi] = useState();
  const [bmimessage, setBmiMessage] = useState("")
  const [isOpen, setOpen] = useState(false)
  const [isOpenPic, setOpenPic] = useState(false)
  const [results, setResults] = useState([]);
  const val = '#23b861';
  const navigate = useNavigate();
  let us = "";
  let uname = "";
  try {
    us = JSON.parse(localStorage.getItem('token-info'));
    uname = us.username
  }
  catch {
    navigate("/signin");
  }
  const fetchInfo = async () => {
    const res = await fetch(`http://localhost:1099/users?username=${uname}`)
    const userss = await res.json()
    setResults(userss)
  }

  useEffect(() => {
    fetchInfo()
  }, [propUpdateDetails])


  return (
    <>
      <Header searchReq={false} />
      {
        results.map((dataObj) => {
          return (
            <>
              <div className='prcontainer'>
                <SideBarProfile />
                <div className='rightprofilecontainer'>
                  <div className="profile">
                    <div className="pic">
                      {dataObj.profilepicture == "" ? <img src={profilepic} style={{width:'272px',height:'355px'}} alt='profilePic' /> : <img src={dataObj.profilepicture} style={{width:'272px',height:'355px'}} alt='profilePic' />}
                    </div>
                    <div className="details">
                      <div className="intro">
                        <h1>{dataObj.username}</h1>

                      </div>
                      <div className="contactinfo">
                        <div className="num">
                          <div className="content">


                            <h4> <i className="fa fa-venus-mars" style={{ color: "black" }}></i> Gender  </h4>
                            <h4 className='procol'>:</h4>
                            <h4 >Female</h4>
                          </div>
                        </div>

                        <div className="num">
                          <div className="content">

                            <h4><BsFillTelephoneFill/>Phone  </h4>
                            <h4 className='procol'>:</h4>
                            <h4 >{dataObj.phno}</h4>
                          </div>
                        </div>
                        <div className="num">
                          <div className="content">
                            <h4><MdEmail/> Email </h4>
                            <h4 className='procol'>:</h4>
                            <h4>{dataObj.email}</h4>
                          </div>
                        </div>
                        <div className="num">

                          <div className="content">

                            <h4> <FaLocationDot/> Location  </h4>
                            <h4 className='procol'>:</h4>
                            <h4>Hyderabad</h4>
                          </div>

                        </div>
                      </div>
                      <Dialog open={isOpen} onClose={() => { setOpen(false) }}>
                        <Suspense>
                          <ProfileNameUpdate setOpen={setOpen} uid={dataObj.id} email={dataObj.email} password={dataObj.passwordHash} userData={dataObj} phno={dataObj.phno} bloodgroup={dataObj.bloodgroup} wbccount={dataObj.wbccount} rbccount={dataObj.rbccount} height={dataObj.height} weight={dataObj.weight} bmi={nbmi} bmimsg={bmimessage} onClose={setOpen} />
                        </Suspense>
                      </Dialog>
                      <button className='update-button' onClick={() => { setOpen(true) }}>Update Details</button>
                    </div>
                  </div>
                </div>
                <div className='aboutdetails'>
                  <div className="aboutcol">
                    <div className="about">
                      <h2>Health Information</h2>
                      <div className='aboutcontent'>
                        <h4>Blood Group : </h4>
                        <p>{dataObj.bloodgroup}</p>
                      </div>
                      <div className='aboutcontent'>
                        <h4>Red Blood Cells (RBC) Count : </h4>
                        <p>{dataObj.rbccount} millions per cubic millimeter</p>
                      </div>
                      <div className='aboutcontent'>
                        <h4>White Blood Cells (RBC) Count : </h4>
                        <p>{dataObj.wbccount} cells per cubic millimeter </p>
                      </div>
                      <div className='aboutcontent'>
                        <h4>Known Conditions : </h4>
                        <p>{dataObj.conditions}</p>
                      </div>
                      {/* <div className='bmigap'></div> */}
                      <h2>Body Mass Index  </h2>
                      <div className='aboutcontent'>
                        <h4>Height In Centimeter : </h4>
                        <p> {dataObj.height}</p>
                      </div>
                      <div className='aboutcontent'>
                        <h4>Weight in Kilogram : </h4>
                        <p>{dataObj.weight}</p>
                      </div>
                      <div className='aboutcontent'>
                        <h4>Calculated BMI : </h4>
                        <p>{dataObj.bmi} ({dataObj.bmimsg})</p>
                      </div>
                      <h2>Medications </h2>
                      <div className='aboutcontent'>
                        <h4>{dataObj.medication1}</h4>
                      </div>
                      <div className='aboutcontent'>
                        <h4>{dataObj.medication2}</h4>
                      </div>
                    </div>
                  </div>
                </div>
              </div >
            </>
          )
        })
      }

      {/* <Footer /> */}
    </>


  );
}

export default Profile
