/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      spacing: {
        '86': '20.5rem'
      },
      boxShadow: {
        // box-shadow: 0 0 3px
        'all': '0 1px 3px 0px rgba(0, 0, 0, 0.2)',
      }
    },
  },
  plugins: [],
}

